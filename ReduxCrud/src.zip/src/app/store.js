import { configureStore } from '@reduxjs/toolkit'
import ContactSilce from '../Features/Pages/ContactSilce'

export const store = configureStore({
  reducer: {
    user:ContactSilce
  },
})

