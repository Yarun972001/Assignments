import React, { useState, useEffect } from "react";
import Header from "../Component/Header";
import Footer from "../Component/Footer";
import { useSelector, useDispatch } from "react-redux";
import { toast } from "react-toastify";

import { showUser, deleteUser, updateUser } from "../Pages/ContactSilce";

function Manage_Contact() {
  const dispatch = useDispatch();

  const [editId, setEditId] = useState("");
  const [formvalue, setFormvalue] = useState({
    id: "",
    name: "",
    number: "",
    email: "",
    comment: "",
  });
  const { users, loading } = useSelector((state) => state.user);

  useEffect(() => {
    dispatch(showUser());
  }, []);

  const deletehandel = async (id) => {
    dispatch(deleteUser(id));
    dispatch(showUser());
    console.log(users);
  };

  if (loading) {
    return <h2>Loading</h2>;
  }

  const edithandel = (id) => {
    console.log(id);
    const singleUser = users.filter((value) => value.id == id);
    setEditId(id);
    console.log(singleUser);
    setFormvalue(singleUser[0]);
  };

  const changeHandel = (e) => {
    setFormvalue({ ...formvalue, [e.target.name]: e.target.value });
    console.log(formvalue);
  };

  const vadidation = () => {
    var result = true;
    if (formvalue.name == "") {
      toast.error("Name Field is required !");
      result = false;
      return false;
    }
    if (formvalue.email == "") {
      toast.error("email Field is required !");
      result = false;
      return false;
    }

    if (formvalue.comment == "") {
      toast.error("comment Field is required !");
      result = false;
      return false;
    }
    return result;
  };

  const submitHandel = (e) => {
    e.preventDefault();
    if (vadidation()) {
      dispatch(updateUser(editId, formvalue));
      dispatch(showUser());
      setFormvalue({ ...formvalue, name: "", email: "", comment: "" });
      toast.success("Update sucees");
      return false;
    }
  };

  return (
    <>
      <Header />
      <div className="container">
        <div className="row ">
          <div className="col-md-12 ">
            <h1 className="text-center">
              <i>
                <u>Managae Contact</u>
              </i>
            </h1>
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>#ID</th>
                  <th>Name</th>
                  <th>number</th>
                  <th>Email</th>
                  <th>Comment</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {users &&
                  users.map((value, index) => {
                    return (
                      <tr key={index}>
                        <td>{value.id}</td>
                        <td>{value.name}</td>
                        <td>{value.number}</td>
                        <td>{value.email}</td>
                        <td>{value.comment}</td>
                        <td>
                          <button
                            className="btn btn-primary"
                            data-bs-toggle="modal"
                            data-bs-target="#myModal"
                            onClick={() => edithandel(value.id)}
                          >
                            Edit
                          </button>
                          <button
                            className="btn btn-danger"
                            onClick={() => deletehandel(value.id)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    );
                  })}

                <div className="modal" id="myModal">
                  <div className="modal-dialog">
                    <div className="modal-content">
                      {/* Modal Header */}
                      <div className="modal-header">
                        <h4 className="modal-title">Modal Heading</h4>
                        <button
                          type="button"
                          className="btn-close"
                          data-bs-dismiss="modal"
                        />
                      </div>
                      {/* Modal body */}
                      <div className="modal-body">
                        <div className="row">
                          <div className="col-md-12">
                            <form action="" method="post">
                              <div>
                                <input
                                  type="text"
                                  className="form-control mb-2"
                                  style={{ color: "black" }}
                                  value={formvalue.name}
                                  onChange={changeHandel}
                                  name="name"
                                  placeholder="Name"
                                />
                              </div>
                              <div>
                                <input
                                  type="email"
                                  className="form-control mb-2"
                                  style={{ color: "black" }}
                                  value={formvalue.email}
                                  onChange={changeHandel}
                                  name="email"
                                  placeholder="Email"
                                />
                              </div>

                              <div>
                                <input
                                  type="number"
                                  className="form-control mb-2"
                                  style={{ color: "black" }}
                                  value={formvalue.number}
                                  onChange={changeHandel}
                                  name="number"
                                  placeholder="number"
                                />
                              </div>

                              <div>
                                <input
                                  type="text"
                                  className="form-control mb-2"
                                  style={{ color: "black" }}
                                  value={formvalue.comment}
                                  onChange={changeHandel}
                                  name="comment"
                                  placeholder="comment"
                                />
                              </div>

                              <div className="d-flex ">
                                <button
                                  onClick={submitHandel}
                                  className="btn btn-danger"
                                >
                                  Save
                                </button>
                              </div>
                            </form>
                          </div>
                          <div className="col-md-6">
                            <div className="map_container">
                              <div className="map">
                                <div
                                  id="googleMap"
                                  style={{ width: "100%", height: "100%" }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default Manage_Contact;
