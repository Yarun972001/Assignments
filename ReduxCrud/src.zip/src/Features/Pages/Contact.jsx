import React, { useState } from 'react'
import { toast } from 'react-toastify';
import { useDispatch } from 'react-redux';
import Header from '../Component/Header';
import Footer from '../Component/Footer';
import { inserUser } from './ContactSilce';



function Contact() {

  const dispatch=useDispatch();
  const [formvalue, setFormvalue] = useState({
      id: "",
      name: "",
      number:"",
      email: "",
      comment: ""
  });

  const changeHandel = (e) => {
      setFormvalue({ ...formvalue, id: new Date().getTime().toString(), [e.target.name]: e.target.value });
      console.log(formvalue);
  }

  const vadidation = () => {
      var result = true;
      if (formvalue.name == "") {
          toast.error('Name Field is required !')
          result = false;
          return false;
      }
      if (formvalue.email == "") {
          toast.error('email Field is required !')
          result = false;
          return false;
      }

      if (formvalue.comment == "") {
          toast.error('comment Field is required !')
          result = false;
          return false;
      }
      return result;
  }
  const submitHandel = async (e) => {
      e.preventDefault();
      if (vadidation()) {
          dispatch(inserUser(formvalue));
          setFormvalue({ ...formvalue, name: "", email: "", number:"", comment: ""});
          toast.success('Data Add sucees');
      }

  }



  return (

    <>
      <Header />
      <div className="container">
        <div className="row ">
          <div className="col-md-8 offset-md-2">
            <h1 className="text-center"><i><u>Add Contact</u></i></h1>
            <form method='post' onSubmit={submitHandel}>
              <div className="form-group">
                <label htmlFor="name">Your Name:</label>
                <input name="contact_name" value={formvalue.name} onChange={changeHandel}  type='text' className="form-control" id="name" placeholder="Enter your name" required />
              </div>
              <div className="form-group">
                <label htmlFor="Number">Phone Number:</label>
                <input name="contact_number" value={formvalue.number} onChange={changeHandel} type='number' className="form-control" id="number" placeholder="Enter your number" required />
              </div>
              <div className="form-group">
                <label htmlFor="email">Your Email:</label>
                <input name="contact_email" value={formvalue.email} onChange={changeHandel} type='email' className="form-control" id="email" placeholder="Enter your email" required />
              </div>
              <div className="form-group">
                <label htmlFor="message">Your Message:</label>
                <textarea name="contact_msg"value={formvalue.comment} onChange={changeHandel} className="form-control" id="message" placeholder="Enter your message" required defaultValue={""} />
              </div>
              <button type="submit" className="btn btn-primary" >Submit</button>
            </form>
          </div>
        </div>
      </div>
      <Footer />
    </>

  )
}

export default Contact