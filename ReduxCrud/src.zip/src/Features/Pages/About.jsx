import React from 'react'
import Header from '../Component/Header'
import Footer from '../Component/Footer'

function About() {
  return (
    <>
    
    <Header/>
    <div>
  {/* SIDEBAR */}
  {/* <SIDEBAR> */}
  <div className="container-fluid">
    <div className="row  main">
      <div className="col-md-4 bg-black " style={{marginTop: 65}}>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore, deleniti aut eveniet saepe accusantium omnis
        esse voluptatem suscipit. Dolorem maxime odio pariatur eius modi ex exercitationem dolorum voluptates eaque,
        commodi perferendis, numquam voluptatum culpa hic tempore <main>. Tempore optio alias accusamus</main> nihil
        eos ipsam reiciendis aliquriam asperiores. Nulla magnam iste reprehenderit obcaecati placeat impedit officiis
        at commodi neque aliquam, culpa nihil molestias eum error omnis nam ab. Aspernatur fugit asperiores qui at
        <br />eum quod nam?
      </div>
      <div className="col-md-4">
        {/* <img src="https://tse3.mm.bing.net/th?id=OIP.CbLTCKj39GIC3CY8GKII_wHaEo&pid=Api&P=0" width="102%" alt="gym"> */}
        <img src="https://tse4.mm.bing.net/th?id=OIP.gQ-OF8p6zaU14QBJfVnHFgHaE8&pid=Api&P=0" alt />
      </div>
      <div className="col-md-4" style={{marginTop: 65}}>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore, deleniti aut eveniet saepe accusantium omnis
        esse voluptatem suscipit. Dolorem maxime odio pariatur eius modi ex exercitationem dolorum voluptates eaque,
        commodi perferendis, numquam voluptatum culpa hic tempore <main>. Tempore optio alias accusamus</main> nihil
        eos ipsam reiciendis aliquriam asperiores. Nulla magnam iste reprehenderit obcaecati placeat impedit officiis
        at commodi neque aliquam, culpa nihil molestias eum error omnis nam ab. Aspernatur fugit asperiores qui at
        <br />eum quod nam?
      </div>
    </div>
  </div>
  </div>


    
    <Footer/>

    </>
  )
}

export default About