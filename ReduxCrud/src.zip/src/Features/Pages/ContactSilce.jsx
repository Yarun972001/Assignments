import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const showUser = createAsyncThunk("showUser", async () => {
  const response = await axios.get("http://localhost:3000/user");
  return response.data;
});

export const deleteUser = createAsyncThunk("deleteUser", async (id) => {
  const response = await axios.delete(`http://localhost:3000/user/${id}`);
  return response;
});

export const inserUser = createAsyncThunk("inserUser", async (formvalue) => {
  const response = await axios.post(`http://localhost:3000/user`, formvalue);
  return response;
});

export const updateUser = createAsyncThunk("updateUser",async (id,formvalue) => 
{
    axios.patch(`http://localhost:3000/user/${id}`,formvalue)
    .then((response) => {
      console.log(response);
      return response.data
      
    })
  }
);

export const ContactSlice = createSlice({
  name: "user",
  initialState: {
    number: 1,
    contact: [],
    loading: false, 
  },
  reducers: {

    [showUser.fulfilled]: (state, action) => {
      state.loading = false;
      state.users = action.payload;
    },

    [deleteUser.fulfilled]: (state, action) => {
      state.loading = false;
    },
    [updateUser.fulfilled]: (state, action) => {
      state.loading = false;
    },
  },
});


export default ContactSlice.reducer;
