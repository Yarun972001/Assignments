import React from 'react'
import Header from '../Component/Header'
import Footer from '../Component/Footer'

function Home() {
  return (
    <>
    <Header/>
<div>
  {/* BANNER */}
  <div className="container-fluid" >
    <div className="row main bg-black " style={{color: 'aliceblue'}}>
      <div className="col-md-12">
        <img src="http://getwallpapers.com/wallpaper/full/e/b/e/200379.jpg" width="100%" alt="gym" />
      </div>
      <div className="col-md-6" >
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Impedit maiores quisquam, voluptate fuga natus
        officiis ad laudantium quibusdam error cupiditate aliquid minus neque <main>dsdjsjfsnfksn</main> optio
        distinctio minima qui id excepturi facilis, repellat temporibus. Nesciunt in, saepe commodi ex eius tenetur
        illo debitis minima spa <br /> sed impedit aut, doloribus eos similique recusandae ullam <br />Lorem ipsum dolor
        sit amet, consectetur adipisicing elit. Suscipit eum ipsa earum quod cum in eius, maiores tempora,
        exercitationem et tenetur dolor commodi odio quisquam nesciunt tempor <br /> ibus iste ipsam voluptates!
        <br />sdnsndusfysfvdb fdlihldv
        <br />
        sdnsjnd
      </div>
    </div>
  </div>
  {/* SIDEBAR */}
  {/* <SIDEBAR> */}
  <div className="container-fluid">
    <div className="row  main">
      <div className="col-md-4 bg-black " style={{marginTop: 65}}>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore, deleniti aut eveniet saepe accusantium omnis
        esse voluptatem suscipit. Dolorem maxime odio pariatur eius modi ex exercitationem dolorum voluptates eaque,
        commodi perferendis, numquam voluptatum culpa hic tempore <main>. Tempore optio alias accusamus</main> nihil
        eos ipsam reiciendis aliquriam asperiores. Nulla magnam iste reprehenderit obcaecati placeat impedit officiis
        at commodi neque aliquam, culpa nihil molestias eum error omnis nam ab. Aspernatur fugit asperiores qui at
        <br />eum quod nam?
      </div>
      <div className="col-md-4">
        {/* <img src="https://tse3.mm.bing.net/th?id=OIP.CbLTCKj39GIC3CY8GKII_wHaEo&pid=Api&P=0" width="102%" alt="gym"> */}
        <img src="https://tse4.mm.bing.net/th?id=OIP.gQ-OF8p6zaU14QBJfVnHFgHaE8&pid=Api&P=0" alt />
      </div>
      <div className="col-md-4" style={{marginTop: 65}}>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Labore, deleniti aut eveniet saepe accusantium omnis
        esse voluptatem suscipit. Dolorem maxime odio pariatur eius modi ex exercitationem dolorum voluptates eaque,
        commodi perferendis, numquam voluptatum culpa hic tempore <main>. Tempore optio alias accusamus</main> nihil
        eos ipsam reiciendis aliquriam asperiores. Nulla magnam iste reprehenderit obcaecati placeat impedit officiis
        at commodi neque aliquam, culpa nihil molestias eum error omnis nam ab. Aspernatur fugit asperiores qui at
        <br />eum quod nam?
      </div>
    </div>
  </div>
  </div>
  <Footer/>
  


    </>
  )
}

export default Home