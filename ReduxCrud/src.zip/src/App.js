import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./Features/Pages/Home";
import About from "./Features/Pages/About";
import Contact from "./Features/Pages/Contact";
import Manage_contact from "./Features/Pages/Manage_contact";


function App() {
  return (
   <>
   <BrowserRouter>
   <Routes>
    <Route path="/" element={<><Home/></>}></Route>
    <Route path="/About" element={<><About/></>}></Route>
    <Route path="/Contact" element={<><Contact/></>}></Route>
    <Route path="/Manage_contact" element={<><Manage_contact/></>}></Route>
    
   </Routes>
   </BrowserRouter>
   </>
  );
}

export default App;
