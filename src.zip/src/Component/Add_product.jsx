import React,{useState,useEffect} from 'react'
import axios from 'axios'

import { toast } from 'react-toastify';

function Add_product() {

    const [data, setData] = useState([]);

    useEffect(() => {
        fetch();
    }, []);

    const fetch = async () => {
        const res = await axios.get(`http://localhost:3000/categories`);
        //console.log(res.data);
        setData(res.data);
    }

    const [formvalue,setFormvalue]=useState({
        id:"",
        cate_id:"",
        prod_name:"",
        price:"",
        desc:"",
        img:""
    });

    const changeHandel=(e)=>{
        setFormvalue({...formvalue,id: new Date().getTime().toString(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }

    const submitHandel= async (e)=>{
        e.preventDefault();
        const res=await axios.post(`http://localhost:3000/product`,formvalue);
        if(res.status==201)
        {
            toast.success('Product Add Success');
            setFormvalue({...formvalue,cate_id:"",prod_name:"",price:"",desc:"",img:""});
            return false;
        }
        
    }

    return (

                <div className="container ">
                    <div className="col-md-12 col-sm-12 col-xs-12">
                        <div className="panel panel-primary">
                            <div className="panel-heading">
                             <h1>   Add Product </h1>
                            </div>
                            <div className="panel-body">
                                <form method="post">
                                    <div className="form-group">
                                        <label>Enter Categories Name</label>
                                        <select name="cate_id" onChange={changeHandel} className="form-control" type="text" >
                                            <option value="">----- Select One Service Categories -----</option>   
                                           {
                                            data.map((value)=>{
                                                return(
                                                    <option value={value.id}>{value.cate_name}</option>   
                                                )
                                            })
                                           }
                                           
                                        </select>           
                                    </div>
                                    <div className="form-group">
                                        <label>Enter Product Name</label>
                                        <input name="prod_name" onChange={changeHandel} value={formvalue.prod_name} className="form-control" type="text" />           
                                    </div>
                                    <div className="form-group">
                                        <label>Enter Product Price</label>
                                        <input name="price" onChange={changeHandel} value={formvalue.price} className="form-control" type="number" />           
                                    </div>
                                    <div className="form-group">
                                        <label>Enter Prodct Description</label>
                                        <textarea name="desc" onChange={changeHandel} value={formvalue.desc} className="form-control"></textarea>           
                                    </div>
                                    <div className="form-group">
                                        <label>Upload Categories Image Path</label>
                                        <input name="img" onChange={changeHandel} value={formvalue.img} className="form-control" type="url" />
                                    </div>
                                    <button type="submit" onClick={submitHandel} className="btn btn-info">Submit </button>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>

    )
}

export default Add_product