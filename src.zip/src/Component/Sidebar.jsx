import React from 'react'
import { NavLink } from 'react-router-dom'

function Sidebar() {
  return (
    
    <div className="container">
    <div className="row">
      <nav className="col-md-12">
        <h1> ADMIN PANEL</h1>
        <div className="sidebar-sticky">
          <ul className="nav flex-row">
            <li className="nav-item">
              <button className="nav-link btn btn-primary mt-4 btn-block " data-toggle="collapse" data-target="#dropdownExampleUser" aria-expanded="false" aria-controls="dropdownExampleUser">
                User
              </button>
              <div className="collapse" id="dropdownExampleUser">
                <ul className="nav flex-column">
                  <li className="nav-item ">
                    <NavLink className="nav-link" to="/Add_User">Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage_User">Manage</NavLink>
                  </li>
                </ul>
              </div>
            </li>
            <li className="nav-item ms-5">
              <button className="nav-link btn btn-success mt-4 ms-5" data-toggle="collapse" data-target="#dropdownExampleEmployee" aria-expanded="false" aria-controls="dropdownExampleEmployee">
                Employee
              </button>
              <div className="collapse" id="dropdownExampleEmployee">
                <ul className="nav flex-column">
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Add_employee">Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage_employee">Manage</NavLink>
                  </li>
                </ul>
              </div>
            </li>
            <li className="nav-item"> 
              <button className="nav-link btn btn-primary mt-4 btn-block" data-toggle="collapse" data-target="#dropdownExampleGuard" aria-expanded="false" aria-controls="dropdownExampleGuard">
                Guard
              </button>
              <div className="collapse" id="dropdownExampleGuard">
                <ul className="nav flex-column">
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Add_categories">Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage-categories">Manage</NavLink>
                  </li>
                </ul>
              </div>
            </li>
            <li className="nav-item">
              <button className="nav-link btn btn-success mt-4 btn-block" data-toggle="collapse" data-target="#dropdownExampleProduct" aria-expanded="false" aria-controls="dropdownExampleProduct">
                Product
              </button>
              <div className="collapse" id="dropdownExampleProduct">
                <ul className="nav flex-column">
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Add_product">Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage_product">Manage</NavLink>
                  </li>
                </ul>
              </div>
            </li>
            <li className="nav-item">
              <button className="nav-link btn btn-primary mt-4 btn-block" data-toggle="collapse" data-target="#dropdownExampleContact" aria-expanded="false" aria-controls="dropdownExampleContact">
                Contact
              </button>
              <div className="collapse" id="dropdownExampleContact">
                <ul className="nav flex-column">
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Add_Contact">Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage_Contact">Manage</NavLink>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </nav>
      {/* Content */}
      <main role="main" className="col-md-9 ml-sm-auto col-lg-10 px-4">
        {/* Your page content goes here */}
      </main>
    </div>
  </div>
  
  )
}

export default Sidebar




