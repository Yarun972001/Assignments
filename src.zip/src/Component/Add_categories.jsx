import React,{useState} from 'react'
import axios from 'axios'

import { toast } from 'react-toastify';

function Add_categories() {


    const [formvalue,setFormvalue]=useState({
        id:"",
        cate_name:"",
        cate_img:"",
        cate_email:"",
    });

    const changeHandel=(e)=>{
        setFormvalue({...formvalue,id: new Date().getTime().toString(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }

    const submitHandel= async (e)=>{
        e.preventDefault();
        const res=await axios.post(`http://localhost:3000/categories`,formvalue);
        if(res.status==201)
        {
            toast.success('Categories Add Success');
            setFormvalue({...formvalue,cate_name:"",cate_img:"",cate_email:""});
            return false;
        }
        
    }

    return (

        <div className='container '>
                    <h1 className="page-head-line">Add Categories</h1>
                        <div className="panel panel-primary">
                            <div className="panel-body">
                                <form method="post">
                                    <div className="form-group">
                                        <label>Enter Categories Name</label>
                                        <input name="cate_name" onChange={changeHandel} value={formvalue.cate_name} className="form-control" type="text" />           
                                    </div>
                                    <div className="form-group">
                                        <label>Upload Categories Image Path</label>
                                        <input name="cate_img" onChange={changeHandel} value={formvalue.cate_img} className="form-control" type="url" />
                                    </div>
                                    <div className="form-group">
                                        <label>Add Categories email</label>
                                        <input name="cate_email" onChange={changeHandel} value={formvalue.cate_email} className="form-control" type="email" />
                                    </div>
                                    <button type="submit" onClick={submitHandel} className="btn btn-info">Submit </button>
                                </form>
                            </div>
                        </div>
                    </div>

    )
}

export default Add_categories