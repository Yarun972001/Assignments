import React,{useState} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';

function Add_Contact() {

    const [formvalue,setFormvalue]=useState({
        id:"",
        contact_name:"",
        contact_email:"",
        contact_msg:"",
        contact_number:""
    });
    const changeHandel=(e)=>{
        setFormvalue({...formvalue,id: new Date().getTime().toString(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }
    const vadidation = () => {
      var result = true;
      if (formvalue.name == "") {
          toast.error('Name Field is required !')
          result = false;
      }
      if (formvalue.email == "") {
          toast.error('email Field is required !')
          result = false;
      }

      if (formvalue.comment == "") {
          toast.error('comment Field is required !')
          result = false;
      }
      return result;
  }
    const submitHandel = async (e) => {
      e.preventDefault();
      if (vadidation()) {
          const res = await axios.post(`http://localhost:3000/contact`, formvalue);
          if (res.status == 201) {
              toast.success('contact Add Success');
              setFormvalue({ ...formvalue, contact_name:"", contact_email:"", contact_msg:"",contact_number:""});
              return false;
          }
      }

  }

  return (
<div className="container">
  <h2 className="text-center">Contact Us</h2>
  <form>
    <div className="form-group">
      <label htmlFor="name">Your Name:</label>
      <input name="contact_name" type='text' className="form-control" onChange={changeHandel} value={formvalue.contact_name} id="name" placeholder="Enter your name" required />
    </div>
    <div className="form-group">
      <label htmlFor="Number">Phone Number:</label>
      <input name="contact_number" type='number' className="form-control" onChange={changeHandel} value={formvalue.contact_number} id="" placeholder="Enter your number" required />
    </div>
    <div className="form-group">
      <label htmlFor="email">Your Email:</label>
      <input name="contact_email" type='email' className="form-control" onChange={changeHandel} value={formvalue.contact_email} id="email" placeholder="Enter your email" required />
    </div>
    <div className="form-group">
      <label htmlFor="message">Your Message:</label>
      <textarea name="contact_msg" className="form-control" id="message" onChange={changeHandel} value={formvalue.contact_msg} rows={4} placeholder="Enter your message" required defaultValue={""} />
    </div>
    <button type="submit" className="btn btn-primary"  onClick={submitHandel}>Submit</button>
  </form>
</div>

  )
}

export default Add_Contact