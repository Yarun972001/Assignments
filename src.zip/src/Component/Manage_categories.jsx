import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';
function Manage_Categories() {

    const [data, setData] = useState([]);

    useEffect(() => {
        fetch();
    }, []);

    const fetch = async () => {
        const res = await axios.get(`http://localhost:3000/categories`);
        //console.log(res.data);
        setData(res.data);
    }
    const deletehandel=async(id)=>{
        const res=await axios.delete(`http://localhost:3000/categories/${id}`);
        //console.log(res);
        if(res.status==200)
        {
            toast.success('Categories Delete Success');
            fetch();
        }
    }

    return (
        <div className="container ">
            <h2 className="text-center">Manage Guard</h2>
            <table className="table table-bordered">
                <thead>
                    <tr>
                        <th >ID</th>
                        <th >Name</th>
                        <th >Image</th>
                        <th >Email</th>
                        <th >Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        data.map((value) => {

                            return (
                                <tr>
                                    <td>{value.id}</td>
                                    <td>{value.cate_name}</td>
                                    <td><img src={value.cate_img} alt="" width="100px" /></td>
                                    <td>{value.cate_email}</td>
                                    <td>
                                        <button className='btn btn-danger' onClick={()=>deletehandel(value.id)}>Delete</button>
                                    </td>
                                </tr>
                            )
                        })
                    }

                </tbody>
            </table>
        </div>

    )
}

export default Manage_Categories