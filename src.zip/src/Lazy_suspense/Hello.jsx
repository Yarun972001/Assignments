import React,{useEffect} from 'react'

function Hello() {
  
  useEffect(()=>{
   // alert('Import');
  },[])
    
  return (
    <div>
        <h1>Hello .... </h1>
    </div>
  )
}

export default Hello