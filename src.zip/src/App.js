
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Sidebar from "./Component/Sidebar";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Manage_categories from "./Component/Manage_categories";
import Add_categories from "./Component/Add_categories";
import Add_employee from "./Component/Add_employee";
import Add_product from "./Component/Add_product";
import Manage_product from "./Component/Manage_product";
import Manage_employee from "./Component/Manage_employee";
import Add_Contact from "./Component/Add_Contact";
import Manage_Contact from "./Component/Manage_Contact";

import Add_User from "./Component/Add_User";
import Manage_User from "./Component/Manage_User";
import Main_lazy from "./Lazy_suspense/Main_lazy";



function App() {
  return (

    
    <BrowserRouter>
       <Main_lazy/> 
    <ToastContainer />
    <Routes>
   
      <Route path="/" element={<><Sidebar/></>}></Route>
      <Route path="/Add_User" element={<><Sidebar/><Add_User/></>}></Route>
      <Route path="/Manage_User" element={<><Sidebar/><Manage_User/></>}></Route>
      
      
      <Route path="/Add_categories" element={<><Sidebar/><Add_categories/></>}></Route>
      <Route path="/Manage-categories" element={<><Sidebar/><Manage_categories/></>}> </Route>
      <Route path="/Add_employee" element={<><Sidebar/><Add_employee/></>}></Route>
      <Route path="/Add_product" element={<><Sidebar/><Add_product/></>}></Route>
      <Route path="/Manage_product" element={<><Sidebar/><Manage_product/></>}></Route>
      <Route path="/Manage_employee" element={<><Sidebar/><Manage_employee/></>}></Route>
      <Route path="/Add_Contact" element={<><Sidebar/><Add_Contact/></>}></Route>
      <Route path="/Manage_Contact" element={<><Sidebar/><Manage_Contact/></>}></Route>


    </Routes>
    </BrowserRouter>
  );
}

export default App;
